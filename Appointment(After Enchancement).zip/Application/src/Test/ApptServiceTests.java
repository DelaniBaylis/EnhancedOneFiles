package Test;

import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.Test;
import java.util.Date;


import Appointment.AppointmentService;

class AppointmentServiceTest extends AppointmentService{

	protected String appointID;           //initialize protected string appointID
	protected Date appointDate = Date(0, 0, 0);          //initialize protected Date appointDate
	protected String appointDescription;   //initialize protected string appointDescription
	
	protected void setAppointID() {
	}private Date Date(int i, int j, int k) {
		
		return null;
	}
	{
		appointID = "14925499487";     //assigning value for appointID
	}
	
	protected void setUpAppointDate() {
	}{
		appointDate = Date(8, 21, 25);          //assigning value for appointDate
	}
	
	protected void setUpAppointDescription() {
	}{
		appointDescription = "Schedule a Doctor's Appointment ";          //assigning value for description
	}
	
	
	@Test
	public void testAddAppointID() {                  //Test method for random appointment ID
		String result = appointID;
		assertTrue(result == "14925499487");
	}
	
	@Test
	public void testAddFalseAppointID() {                  //Test method for random appointment ID
		String result = appointID;
		assertFalse(result == "14925499487164894");
	}
	
	@Test
	public void testAddAppointDate() {                //Test method for appointment name
		Date result = appointDate;
		assertTrue(result == Date(8, 21, 25));
	}
	
	@Test
	public void testAddAppointDescription() {                //Test method for appointment description
		String result = appointDescription;
		assertTrue(result == "Schedule a Doctor's Appointment");
	}
	
	
	@Test
	public void testAddFalseAppointDescription() {                //Test method for appointment description
		String result = appointDescription;
		assertFalse(result == "Schedule a Doctor's Appointment, so that you can get your seasonal checkup");
	}
	
	@AfterEach
	void teardown() {                             //Jupiter teardown after each test
	}

}
