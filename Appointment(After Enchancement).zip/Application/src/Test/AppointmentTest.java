package Test;

import java.util.Date;

import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.DisplayName;          //import for jupiter display name
import org.junit.jupiter.api.Test;

import Appointment.Appointment;

class AppointmentTest {

		@Test
		@DisplayName("Test to see if there is any unique ID in the system")
		void testAppointID() {
			Assertions.assertThrows(IllegalArgumentException.class, () -> {
				new Appointment("14925499487164894", Date(8, 21, 25), "Doctor's Appointment");        
			});        //appointment ID test is connected through Task class
		    
		}
		
		@Test
		@DisplayName("What is to be seen for any past Appointments")
		void testAppointDateTooEarly() {
			Assertions.assertThrows(IllegalArgumentException.class, () -> {
				new Appointment("14925499487", Date(8,21,25), "Doctor's Appiontment");        
			});        //appointment name test is connected through Task class
		}
		
		private Date Date(int i, int j, int k) {
			return null;
		}

		@Test
		@DisplayName("What is to be seen if the Appointments come up as null")
		void testAppointmentDescriptionNull() {
			Assertions.assertThrows(IllegalArgumentException.class, () -> {
				new Appointment("1234567890", null, null);        
			});        //appoint name test is connected through appoint class
		}
		
		@AfterEach
		void teardown() {
		}
		}